Run launch-iracing-agent.cmd. It includes a private Node.js runtime and the native iRacing SDK dependency.
