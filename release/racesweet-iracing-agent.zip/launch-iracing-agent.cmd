@echo off
setlocal
set "AGENT_ROOT=%~dp0"
"%AGENT_ROOT%runtime\node.exe" "%AGENT_ROOT%src\agent\iracingAgentMain.js"
if errorlevel 1 pause