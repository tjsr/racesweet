"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.runIracingAgent = exports.createIracingFrame = void 0;
const irsdk_node_1 = require("irsdk-node");
const iracingRelay_js_1 = require("../utils/iracingRelay.js");
const numericValue = (variable) => {
    const value = variable.value[0];
    return typeof value === 'number' && Number.isFinite(value) ? value : 0;
};
const numericArray = (variable) => variable.value.map((value) => typeof value === 'number' && Number.isFinite(value) ? value : 0);
const booleanArray = (variable) => variable.value.map((value) => value === true || value === 1);
const createIracingFrame = (telemetry, sessionData) => {
    const sessionUniqueId = numericValue(telemetry.SessionUniqueID);
    const sessionNumber = numericValue(telemetry.SessionNum);
    const sessionId = `${sessionUniqueId}:${sessionNumber}`;
    const driverByCarIndex = new Map((sessionData?.DriverInfo.Drivers || [])
        .filter((driver) => Number.isFinite(driver.CarIdx) && Number.isFinite(driver.UserID) && driver.UserID > 0)
        .map((driver) => [driver.CarIdx, driver.UserID]));
    const lapDistance = numericArray(telemetry.CarIdxLapDistPct);
    const laps = numericArray(telemetry.CarIdxLap);
    const onPitRoad = booleanArray(telemetry.CarIdxOnPitRoad);
    const cars = lapDistance.flatMap((lapDistancePercent, carIndex) => {
        const customerId = driverByCarIndex.get(carIndex);
        if (customerId === undefined || lapDistancePercent < 0 || lapDistancePercent > 1) {
            return [];
        }
        return [{
                customerId,
                lapDistancePercent,
                lapNumber: laps[carIndex] || 0,
                onPitRoad: onPitRoad[carIndex] || false,
            }];
    });
    return cars.length > 0 ? { cars, sessionId, sessionTimeSeconds: numericValue(telemetry.SessionTime) } : undefined;
};
exports.createIracingFrame = createIracingFrame;
const runIracingAgent = async (config, api, sdk = new irsdk_node_1.IRacingSDK({ autoEnableTelemetry: true }), signal) => {
    const started = sdk.startSDK();
    if (!started) {
        throw new Error('The iRacing SDK could not be started. Is iRacing running with telemetry enabled?');
    }
    await api.login({ password: config.password, username: config.username });
    let previous;
    let pending = [];
    try {
        while (!signal?.aborted) {
            if (sdk.waitForData(config.pollIntervalMs)) {
                const frame = (0, exports.createIracingFrame)(sdk.getTelemetry(), sdk.getSessionData());
                if (frame) {
                    pending = [...pending, ...(0, iracingRelay_js_1.createIracingRelayRecords)(previous, frame, config.timingLines)];
                    previous = frame;
                }
            }
            if (pending.length > 0) {
                try {
                    await api.sendRecords(config.sourceId, config.sessionId, pending.slice(0, 100));
                    pending = pending.slice(100);
                }
                catch (error) {
                    console.warn(`RaceSweet iRacing upload failed; retaining ${pending.length} record(s): ${error instanceof Error ? error.message : String(error)}`);
                }
            }
        }
    }
    finally {
        sdk.stopSDK();
    }
};
exports.runIracingAgent = runIracingAgent;
//# sourceMappingURL=iracingAgent.js.map