"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.loadIracingAgentConfig = exports.createIracingAgentConfig = void 0;
const node_crypto_1 = require("node:crypto");
const node_fs_1 = require("node:fs");
const propertyOrEnvironment = (properties, environment, propertyName, environmentName) => environment[environmentName] || properties[propertyName];
const decryptPassword = (properties, environment) => {
    const encrypted = propertyOrEnvironment(properties, environment, 'passwordEncrypted', 'RACESWEET_PASSWORD_ENCRYPTED');
    const baseUrl = propertyOrEnvironment(properties, environment, 'url', 'RACESWEET_URL');
    const sourceId = propertyOrEnvironment(properties, environment, 'sourceId', 'RACESWEET_SOURCE_ID');
    const sessionId = propertyOrEnvironment(properties, environment, 'sessionId', 'RACESWEET_SESSION_ID');
    const username = propertyOrEnvironment(properties, environment, 'username', 'RACESWEET_USERNAME');
    if (!encrypted || !baseUrl || !sourceId || !sessionId || !username) {
        return '';
    }
    const [version, ivText, tagText, cipherText] = encrypted.split(':');
    if (version !== 'v1' || !ivText || !tagText || !cipherText) {
        return '';
    }
    const key = (0, node_crypto_1.createHash)('sha256').update(`${baseUrl}\0${sourceId}\0${sessionId}\0${username}`).digest();
    const decipher = (0, node_crypto_1.createDecipheriv)('aes-256-gcm', key, Buffer.from(ivText, 'base64url'));
    decipher.setAuthTag(Buffer.from(tagText, 'base64url'));
    return Buffer.concat([decipher.update(Buffer.from(cipherText, 'base64url')), decipher.final()]).toString('utf8');
};
const requiredValue = (name, value) => {
    if (value) {
        return value;
    }
    throw new Error(`Missing ${name}. Set it in racesweet.properties or the environment.`);
};
const createIracingAgentConfig = (properties, environment) => {
    const configuredPassword = environment.RACESWEET_PASSWORD || decryptPassword(properties, environment);
    return {
        baseUrl: requiredValue('RACESWEET_URL', propertyOrEnvironment(properties, environment, 'url', 'RACESWEET_URL')),
        password: requiredValue('RACESWEET_PASSWORD', configuredPassword),
        pollIntervalMs: Number(environment.RACESWEET_POLL_INTERVAL_MS || properties.pollIntervalMs || 16),
        sessionId: requiredValue('RACESWEET_SESSION_ID', propertyOrEnvironment(properties, environment, 'sessionId', 'RACESWEET_SESSION_ID')),
        sourceId: requiredValue('RACESWEET_SOURCE_ID', propertyOrEnvironment(properties, environment, 'sourceId', 'RACESWEET_SOURCE_ID')),
        timingLines: JSON.parse(environment.RACESWEET_TIMING_LINES || properties.timingLines || '[{"id":"finish","kind":"finish","lapDistancePercent":0}]'),
        username: requiredValue('RACESWEET_USERNAME', propertyOrEnvironment(properties, environment, 'username', 'RACESWEET_USERNAME')),
    };
};
exports.createIracingAgentConfig = createIracingAgentConfig;
const loadIracingAgentConfig = (propertiesPath, environment) => {
    const properties = (() => {
        try {
            return Object.fromEntries((0, node_fs_1.readFileSync)(propertiesPath, 'utf8')
                .split(/\r?\n/gu)
                .filter((line) => line.trim().length > 0 && !line.trim().startsWith('#'))
                .map((line) => {
                const separator = line.indexOf('=');
                return [line.slice(0, separator).trim(), line.slice(separator + 1).trim()];
            }));
        }
        catch {
            return {};
        }
    })();
    return (0, exports.createIracingAgentConfig)(properties, environment);
};
exports.loadIracingAgentConfig = loadIracingAgentConfig;
//# sourceMappingURL=iracingAgentConfig.js.map