"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const node_crypto_1 = require("node:crypto");
const vitest_1 = require("vitest");
const iracingAgentConfig_js_1 = require("./iracingAgentConfig.js");
const createEncryptedPassword = (password, url, sourceId, sessionId, username) => {
    const key = (0, node_crypto_1.createHash)('sha256').update(`${url}\0${sourceId}\0${sessionId}\0${username}`).digest();
    const iv = (0, node_crypto_1.randomBytes)(12);
    const cipher = (0, node_crypto_1.createCipheriv)('aes-256-gcm', key, iv);
    const cipherText = Buffer.concat([cipher.update(password, 'utf8'), cipher.final()]);
    return `v1:${iv.toString('base64url')}:${cipher.getAuthTag().toString('base64url')}:${cipherText.toString('base64url')}`;
};
(0, vitest_1.describe)('createIracingAgentConfig', () => {
    (0, vitest_1.it)('uses the properties username instead of the Windows USERNAME environment variable when decrypting the password', () => {
        const url = 'http://127.0.0.1:8080';
        const sourceId = 'iracing-agent';
        const sessionId = 'active';
        const username = 'admin';
        const password = 'adminadminadmin';
        const properties = {
            passwordEncrypted: createEncryptedPassword(password, url, sourceId, sessionId, username),
            sessionId,
            sourceId,
            url,
            username,
        };
        const config = (0, iracingAgentConfig_js_1.createIracingAgentConfig)(properties, { USERNAME: 'WindowsUser' });
        (0, vitest_1.expect)(config.password).toBe(password);
        (0, vitest_1.expect)(config.username).toBe(username);
    });
});
//# sourceMappingURL=iracingAgentConfig.test.js.map