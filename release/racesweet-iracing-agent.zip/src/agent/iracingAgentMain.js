"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const node_path_1 = __importDefault(require("node:path"));
const iracingAgentApiClient_js_1 = require("./iracingAgentApiClient.js");
const iracingAgentConfig_js_1 = require("./iracingAgentConfig.js");
const iracingAgent_js_1 = require("./iracingAgent.js");
const propertiesPath = node_path_1.default.resolve(node_path_1.default.dirname(process.argv[1] || ''), '..', '..', 'racesweet.properties');
const config = (0, iracingAgentConfig_js_1.loadIracingAgentConfig)(propertiesPath, process.env);
const controller = new AbortController();
process.once('SIGINT', () => controller.abort());
process.once('SIGTERM', () => controller.abort());
void (0, iracingAgent_js_1.runIracingAgent)(config, (0, iracingAgentApiClient_js_1.createIracingAgentApi)(config.baseUrl), undefined, controller.signal)
    .catch((error) => {
    console.error(error instanceof Error ? error.stack || error.message : String(error));
    process.exitCode = 1;
});
//# sourceMappingURL=iracingAgentMain.js.map