"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createIracingAgentApi = void 0;
const createIracingAgentApi = (baseUrl) => {
    let cookie;
    const request = async (path, init) => {
        const headers = new Headers(init.headers);
        headers.set('content-type', 'application/json');
        if (cookie) {
            headers.set('cookie', cookie);
        }
        const response = await fetch(new URL(path, baseUrl), { ...init, headers });
        if (!response.ok) {
            throw new Error(`RaceSweet request ${path} returned HTTP ${response.status}.`);
        }
        return response;
    };
    return {
        login: async (credentials) => {
            const response = await request('/api/v1/auth/login', {
                body: JSON.stringify(credentials),
                method: 'POST',
            });
            const setCookie = response.headers.getSetCookie();
            cookie = setCookie[0]?.split(';', 1)[0];
            if (!cookie) {
                throw new Error('RaceSweet login did not return a session cookie.');
            }
        },
        sendRecords: async (sourceId, sessionId, records) => {
            await request('/api/v1/timing/iracing', {
                body: JSON.stringify({ records, sessionId, sourceId }),
                method: 'POST',
            });
        },
    };
};
exports.createIracingAgentApi = createIracingAgentApi;
//# sourceMappingURL=iracingAgentApiClient.js.map