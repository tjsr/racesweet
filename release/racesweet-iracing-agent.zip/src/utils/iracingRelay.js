"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createIracingRelayRecords = void 0;
const crossedLine = (previous, next, line) => (next >= previous ? line > previous && line <= next : line > previous || line <= next);
const interpolateTime = (previous, next, previousProgress, nextProgress, line) => {
    const distance = nextProgress >= previousProgress ? nextProgress - previousProgress : 1 - previousProgress + nextProgress;
    const lineDistance = line >= previousProgress ? line - previousProgress : 1 - previousProgress + line;
    return previous.sessionTimeSeconds + ((next.sessionTimeSeconds - previous.sessionTimeSeconds) * lineDistance / distance);
};
const createIracingRelayRecords = (previous, next, lines) => {
    if (!previous || previous.sessionId !== next.sessionId) {
        return [];
    }
    const previousCars = new Map(previous.cars.map((car) => [car.customerId, car]));
    return next.cars.flatMap((car) => {
        const previousCar = previousCars.get(car.customerId);
        if (!previousCar) {
            return [];
        }
        const records = lines.flatMap((line) => {
            if (!crossedLine(previousCar.lapDistancePercent, car.lapDistancePercent, line.lapDistancePercent)) {
                return [];
            }
            const sessionTimeSeconds = interpolateTime(previous, next, previousCar.lapDistancePercent, car.lapDistancePercent, line.lapDistancePercent);
            const lapNumber = car.lapDistancePercent < previousCar.lapDistancePercent ? car.lapNumber : previousCar.lapNumber;
            return [{ customerId: car.customerId, id: `${next.sessionId}:${car.customerId}:${line.id}:${lapNumber}`, kind: line.kind, lapNumber, lineId: line.id, occurredAt: new Date().toISOString(), sessionId: next.sessionId, sessionTimeSeconds }];
        });
        if (previousCar.onPitRoad !== car.onPitRoad) {
            records.push({ customerId: car.customerId, id: `${next.sessionId}:${car.customerId}:${car.onPitRoad ? 'pit-entry' : 'pit-exit'}:${car.lapNumber}:${next.sessionTimeSeconds}`, kind: car.onPitRoad ? 'pit-entry' : 'pit-exit', lapNumber: car.lapNumber, lineId: car.onPitRoad ? 'pit-entry' : 'pit-exit', occurredAt: new Date().toISOString(), sessionId: next.sessionId, sessionTimeSeconds: next.sessionTimeSeconds });
        }
        return records;
    });
};
exports.createIracingRelayRecords = createIracingRelayRecords;
//# sourceMappingURL=iracingRelay.js.map